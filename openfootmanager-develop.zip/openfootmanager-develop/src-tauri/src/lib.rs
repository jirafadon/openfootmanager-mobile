mod application;
mod commands;
use commands::*;

#[cfg(feature = "mcp")]
mod mcp_server;

use db::save_manager::SaveManager;
use ofm_core::state::StateManager;
use std::sync::{Arc, Mutex};

const SAVE_MANAGER_UNAVAILABLE_ERROR: &str = "be.error.saveManagerUnavailable";

/// Tauri-managed wrapper around SaveManager.
pub struct SaveManagerState(pub Mutex<SaveManager>);

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    // Workaround for WebKitGTK DMABuf rendering issues on Wayland (Linux)
    #[cfg(target_os = "linux")]
    {
        if std::env::var("WEBKIT_DISABLE_DMABUF_RENDERER").is_err() {
            std::env::set_var("WEBKIT_DISABLE_DMABUF_RENDERER", "1");
        }
    }

    let state_manager = Arc::new(StateManager::new());

    let result = tauri::Builder::default()
        .plugin(tauri_plugin_opener::init())
        .plugin(
            tauri_plugin_log::Builder::new()
                .level(log::LevelFilter::Info)
                .level_for("openfootmanager_lib", log::LevelFilter::Debug)
                .level_for("ofm_core", log::LevelFilter::Debug)
                .level_for("engine", log::LevelFilter::Debug)
                .level_for("db", log::LevelFilter::Debug)
                .rotation_strategy(tauri_plugin_log::RotationStrategy::KeepAll)
                .max_file_size(5_000_000) // 5 MB per log file
                .build(),
        )
        .manage(state_manager.clone())
        .setup(move |app| {
            use tauri::Manager as TauriManager;
            let app_data_dir = app
                .path()
                .app_data_dir()
                .map_err(|_| std::io::Error::other(SAVE_MANAGER_UNAVAILABLE_ERROR))?;
            std::fs::create_dir_all(&app_data_dir)
                .map_err(|_| std::io::Error::other(SAVE_MANAGER_UNAVAILABLE_ERROR))?;

            let saves_dir = app_data_dir.join("saves");
            let mut save_manager = SaveManager::init(&saves_dir).map_err(std::io::Error::other)?;

            // Run legacy migration if old saves.db exists
            if db::legacy_migration::has_legacy_db(&app_data_dir) {
                log::info!("[setup] Legacy saves.db detected, migrating...");
                match db::legacy_migration::migrate_legacy_saves(&app_data_dir, &mut save_manager) {
                    Ok(results) => {
                        let success = results
                            .iter()
                            .filter(|r| {
                                matches!(
                                    r,
                                    db::legacy_migration::LegacyMigrationResult::Success { .. }
                                )
                            })
                            .count();
                        let failed = results
                            .iter()
                            .filter(|r| {
                                matches!(
                                    r,
                                    db::legacy_migration::LegacyMigrationResult::Failed { .. }
                                )
                            })
                            .count();
                        log::info!(
                            "[setup] Legacy migration complete: {} succeeded, {} failed",
                            success,
                            failed
                        );
                    }
                    Err(e) => log::error!("[setup] Legacy migration failed: {}", e),
                }
            }

            app.manage(Arc::new(SaveManagerState(Mutex::new(save_manager))));

            // --- MCP server startup (feature-flagged) ---
            #[cfg(feature = "mcp")]
            match mcp_server::config::parse_mcp_config_from_args() {
                Ok(Some(mcp_config)) => {
                use tauri::Manager as TauriManager;
                use tauri::Emitter;

                let sm: Arc<StateManager> = app.state::<Arc<StateManager>>().inner().clone();
                let save_mgr: Arc<SaveManagerState> = app.state::<Arc<SaveManagerState>>().inner().clone();
                let app_handle = app.handle().clone();

                // --no-gui: hide the window
                if mcp_config.no_gui {
                    if let Some(window) = app.get_webview_window("main") {
                        let _ = window.hide();
                        log::info!("[mcp] GUI window hidden (--no-gui)");
                    }
                }

                // --mcp-auto-start: bootstrap game
                if let Some(ref auto_start) = mcp_config.auto_start {
                    log::info!(
                        "[mcp] Auto-starting: world={}, team={:?}",
                        auto_start.world_path, auto_start.team_id
                    );

                    let mgr_name = mcp_config.manager_name
                        .as_deref()
                        .unwrap_or("Agent")
                        .to_string();
                    let mgr_last = mcp_config.manager_last_name
                        .as_deref()
                        .unwrap_or("Manager")
                        .to_string();
                    let mgr_nat = mcp_config.manager_nationality
                        .as_deref()
                        .unwrap_or("England")
                        .to_string();

                    match crate::commands::game::bootstrap_game_for_mcp(
                        &sm,
                        &save_mgr,
                        &auto_start.world_path,
                        auto_start.team_id.as_deref(),
                        &mgr_name,
                        &mgr_last,
                        &mgr_nat,
                    ) {
                        Ok(save_id) => {
                            log::info!("[mcp] Bootstrap complete, save_id={}", save_id);
                            // Notify GUI that a game is now active
                            let _ = app_handle.emit("game-state-changed", ());
                        }
                        Err(e) => {
                            log::error!("[mcp] Bootstrap failed: {}", e);
                            return Err(Box::new(std::io::Error::new(
                                std::io::ErrorKind::Other,
                                format!("MCP auto-start failed: {}", e),
                            )) as Box<dyn std::error::Error + Send + Sync>);
                        }
                    }
                }

                // Spawn MCP server on the tokio runtime
                let mcp_port = mcp_config.port;
                tauri::async_runtime::spawn(async move {
                    if let Err(e) = mcp_server::start_mcp_server(
                        mcp_config,
                        sm,
                        save_mgr,
                        app_handle,
                    )
                    .await
                    {
                        log::error!("[mcp] MCP server failed: {}", e);
                    }
                });

                log::info!("[mcp] Starting MCP server on port {}", mcp_port);
                }
                Ok(None) => {
                    // No --mcp-port, MCP server not requested
                }
                Err(e) => {
                    log::error!("[mcp-config] {}", e);
                    return Err(Box::new(std::io::Error::new(
                        std::io::ErrorKind::InvalidInput,
                        e,
                    )) as Box<dyn std::error::Error + Send + Sync>);
                }
            }

            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            list_world_databases,
            start_new_game,
            export_world_database,
            write_temp_database,
            select_team,
            get_saves,
            load_game,
            get_active_game,
            advance_time,
            advance_time_with_mode,
            upgrade_facility,
            get_finance_snapshot,
            request_board_support,
            request_marketing_campaign,
            request_sponsor_pitch,
            propose_renewal,
            delegate_renewals,
            preview_renewal_financial_impact,
            offer_free_agent_contract,
            preview_free_agent_contract_impact,
            set_contract_exit_intent,
            clear_contract_exit_intent,
            preview_contract_termination,
            terminate_contract_now,
            set_formation,
            set_starting_xi,
            set_play_style,
            set_team_match_roles,
            set_training,
            set_training_schedule,
            set_training_groups,
            set_player_training_focus,
            set_player_squad_role,
            hire_staff,
            release_staff,
            mark_message_read,
            delete_message,
            delete_messages,
            mark_all_messages_read,
            clear_old_messages,
            save_game,
            auto_select_set_pieces,
            toggle_transfer_list,
            toggle_loan_list,
            make_transfer_bid,
            preview_transfer_bid_financial_impact,
            respond_to_offer,
            counter_offer,
            send_scout,
            start_youth_scouting,
            cancel_youth_scouting,
            reassign_youth_scouting,
            check_season_complete,
            advance_to_next_season,
            get_season_awards,
            resolve_message_action,
            start_live_match,
            get_player_match_history,
            get_player_stats_overview,
            get_team_match_history,
            get_team_stats_overview,
            step_live_match,
            apply_match_command,
            get_match_snapshot,
            finish_live_match,
            delete_save,
            skip_to_match_day,
            check_blocking_actions,
            apply_team_talk,
            submit_press_conference,
            exit_to_menu,
            get_settings,
            save_settings,
            clear_all_saves,
            get_available_jobs,
            apply_for_job,
            get_manager_profiles,
            save_manager_profile,
            update_manager_profile,
            delete_manager_profile,
            touch_manager_profile
        ])
        .run(tauri::generate_context!());

    if let Err(error) = result {
        std::panic::panic_any(error);
    }
}
